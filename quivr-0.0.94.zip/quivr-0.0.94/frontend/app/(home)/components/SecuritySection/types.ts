export type SecurityQuestion = {
  question: string;
  answer: string;
};
