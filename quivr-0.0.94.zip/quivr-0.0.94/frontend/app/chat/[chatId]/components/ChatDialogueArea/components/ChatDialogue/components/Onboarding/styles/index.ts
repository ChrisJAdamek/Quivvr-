export const stepsContainerStyle = "flex flex-col gap-2";
