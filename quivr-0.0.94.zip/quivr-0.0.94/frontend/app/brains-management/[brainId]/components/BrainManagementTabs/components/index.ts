export * from "./BrainTabTrigger";
export * from "./KnowledgeTab";
export * from "./PeopleTab";
