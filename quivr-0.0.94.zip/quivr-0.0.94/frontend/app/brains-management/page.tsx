"use client";
import BrainsManagementPage from "./[brainId]/page";

export default BrainsManagementPage;
